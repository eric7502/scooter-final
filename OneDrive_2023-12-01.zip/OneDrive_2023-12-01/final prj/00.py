print(pygame.mixer.get_init())
