import pygame
import sys
import random

pygame.init()

# 창 크기 설정
width, height = 800, 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("전동킥보드 게임")

# 이미지 로드
background_image = pygame.image.load("C:/Users/Loyola/Downloads/363553509_2281086_3529.jpeg")
kick_scooter_image = pygame.image.load("C:/Users/Loyola/Downloads/art_15879648202473_a9fa2d.jpg")
obstacle_traffic_light_image = pygame.image.load("C:/Users/Loyola/Downloads/1520238.png")
obstacle_banana_image = pygame.image.load("C:/Users/Loyola/Downloads/png-transparent-banana-pudding-codemonkey-video-game-monkey-island-game-food-orange.png")
obstacle_car_image = pygame.image.load("C:/Users/Loyola/Downloads/wrtFileImageView.jpg")
obstacle_mother_and_child_image = pygame.image.load("C:/Users/Loyola/Downloads/pngtree-cartoon-mother-s-day-mother-and-child-holding-hands-walking-png-image_1305546.jpg")

# 이미지 크기 조정
background_image = pygame.transform.scale(background_image, (width, height))
kick_scooter_image = pygame.transform.scale(kick_scooter_image, (50, 80))
obstacle_traffic_light_image = pygame.transform.scale(obstacle_traffic_light_image, (50, 50))
obstacle_banana_image = pygame.transform.scale(obstacle_banana_image, (50, 50))
obstacle_car_image = pygame.transform.scale(obstacle_car_image, (50, 50))
obstacle_mother_and_child_image = pygame.transform.scale(obstacle_mother_and_child_image, (50, 50))

# 윤곽선 추가
kick_scooter_image = kick_scooter_image.convert_alpha()
kick_scooter_rect = kick_scooter_image.get_rect(center=(width // 2, height - kick_scooter_image.get_height() - 10))

obstacle_traffic_light_image = obstacle_traffic_light_image.convert_alpha()
obstacle_banana_image = obstacle_banana_image.convert_alpha()
obstacle_car_image = obstacle_car_image.convert_alpha()
obstacle_mother_and_child_image = obstacle_mother_and_child_image.convert_alpha()

# 킥보드 설정
kick_scooter_x = width // 2 - kick_scooter_image.get_width() // 2
kick_scooter_y = height - kick_scooter_image.get_height() - 10
kick_scooter_speed = 5

# 도로 설정
road_color = (169, 169, 169)  # 회색
center_line_color = (255, 255, 0)  # 노란색
center_line_width = 5
road_width = 200
road_change_speed = 1
current_road_width = road_width

# 장애물 설정
obstacle_width = 50
obstacle_height = 50
obstacle_speed = 5
obstacle_frequency = 25
obstacles = []

# 점수 및 타이머 설정
score = 0
time_limit = 120  # 2분
current_time = time_limit * 60  # 초로 변환
font = pygame.font.Font(None, 36)

# 게임 오버 여부
game_over = False

# 게임 루프
clock = pygame.time.Clock()

def draw_text(text, font, color, x, y):
    """텍스트를 화면에 그리는 함수"""
    text_surface = font.render(text, True, color)
    screen.blit(text_surface, (x, y))

def draw_road():
    """도로를 그리는 함수"""
    pygame.draw.rect(screen, road_color, [0, 0, (width - current_road_width) // 2, height])
    pygame.draw.rect(screen, road_color, [(width + current_road_width) // 2, 0, (width - current_road_width) // 2, height])
    pygame.draw.rect(screen, center_line_color, [(width - center_line_width) // 2, 0, center_line_width, height])

while current_time > 0 and not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            print("게임 종료")
            pygame.quit()
            sys.exit()

    # 킥보드 이동
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and kick_scooter_x > (width - current_road_width) // 2:
        kick_scooter_x -= kick_scooter_speed
    if keys[pygame.K_RIGHT] and kick_scooter_x < (width + current_road_width) // 2 - kick_scooter_image.get_width():
        kick_scooter_x += kick_scooter_speed

    # 도로 폭 변화
    current_road_width += random.choice([-1, 1]) * road_change_speed
    if current_road_width < 100 or current_road_width > 300:
        road_change_speed *= -1

    # 장애물 생성
    if random.randrange(0, obstacle_frequency) == 0:
        obstacle_x = random.randrange((width - current_road_width) // 2, (width + current_road_width) // 2 - obstacle_width)
        obstacle_y = -obstacle_height
        obstacle_choice = random.choice([
            obstacle_traffic_light_image,
            obstacle_banana_image,
            obstacle_car_image,
            obstacle_mother_and_child_image
        ])
        obstacles.append([obstacle_x, obstacle_y, obstacle_choice])

    # 장애물 이동
    for obstacle in obstacles:
        obstacle[1] += obstacle_speed

    # 장애물과 킥보드 충돌 감지
    for obstacle in obstacles:
        obstacle_rect = pygame.Rect(obstacle[0], obstacle[1], obstacle_width, obstacle_height)
        kick_scooter_rect = pygame.Rect(kick_scooter_x, kick_scooter_y, kick_scooter_image.get_width(), kick_scooter_image.get_height())

        # 충돌 검사
        if kick_scooter_rect.colliderect(obstacle_rect):
            score -= 20  # 부딪혔을 때 점수 감소
            obstacles.remove(obstacle)

    # 시간 및 점수 갱신
    current_time -= 1
    if current_time % 600 == 0:  # 10초마다 점수 100 증가
        score += 100

    # 게임 오버 조건
    if score < 0:
        game_over = True

    # 화면 지우기
    screen.blit(background_image, (0, 0))

    # 도로 그리기
    draw_road()

    # 킥보드 그리기
    screen.blit(kick_scooter_image, (kick_scooter_x, kick_scooter_y))

    # 장애물 그리기
    for obstacle in obstacles:
        screen.blit(obstacle[2], (obstacle[0], obstacle[1]))

    # 점수 표시
    draw_text(f"Score: {score}", font, (255, 255, 255), width - 150, 10)

    # 시간 표시
    draw_text(f"Time: {current_time // 60:02d}:{current_time % 60:02d}", font, (255, 255, 255), 10, 10)

    # 게임 오버 시 처리
    if game_over:
        draw_text("Game Over", font, (255, 0, 0), width // 2 - 100, height // 2 - 30)
        draw_text(f"Final Score: {score}", font, (255, 255, 255), width // 2 - 120, height // 2 + 20)
        pygame.display.flip()
        pygame.time.delay(3000)  # 3초 대기
        pygame.quit()
        sys.exit()

    # 화면 업데이트
    pygame.display.flip()

    # 초당 프레임 수 설정
    clock.tick(60)

# 게임 종료
pygame.quit()
sys.exit()
