import pygame
import sys
import random
import math

pygame.init()

# 창 크기 설정
width, height = 800, 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("전동킥보드 게임")

# 이미지 로드
background_image = pygame.image.load("C:/Users/Loyola/Downloads/363553509_2281086_3529.jpeg")
kick_scooter_image = pygame.image.load("C:/Users/Loyola/Downloads/art_15879648202473_a9fa2d.jpg")
obstacle_traffic_light_image = pygame.image.load("C:/Users/Loyola/Downloads/1520238.png")
obstacle_banana_image = pygame.image.load("C:/Users/Loyola/Downloads/png-transparent-banana-pudding-codemonkey-video-game-monkey-island-game-food-orange.png")
obstacle_car_image = pygame.image.load("C:/Users/Loyola/Downloads/wrtFileImageView.jpg")
obstacle_mother_and_child_image = pygame.image.load("C:/Users/Loyola/Downloads/pngtree-cartoon-mother-s-day-mother-and-child-holding-hands-walking-png-image_1305546.jpg")

# 이미지 크기 조정
background_image = pygame.transform.scale(background_image, (width, height))
kick_scooter_image = pygame.transform.scale(kick_scooter_image, (50, 80))
obstacle_traffic_light_image = pygame.transform.scale(obstacle_traffic_light_image, (40, 40))
obstacle_banana_image = pygame.transform.scale(obstacle_banana_image, (40, 40))
obstacle_car_image = pygame.transform.scale(obstacle_car_image, (40, 40))
obstacle_mother_and_child_image = pygame.transform.scale(obstacle_mother_and_child_image, (40, 40))

# 윤곽선 추가
kick_scooter_image = kick_scooter_image.convert_alpha()
kick_scooter_rect = kick_scooter_image.get_rect(center=(width // 2, height - kick_scooter_image.get_height() - 10))

obstacle_traffic_light_image = obstacle_traffic_light_image.convert_alpha()
obstacle_banana_image = obstacle_banana_image.convert_alpha()
obstacle_car_image = obstacle_car_image.convert_alpha()
obstacle_mother_and_child_image = obstacle_mother_and_child_image.convert_alpha()

# 킥보드 설정
kick_scooter_x = width // 2 - kick_scooter_image.get_width() // 2
kick_scooter_y = height - kick_scooter_image.get_height() - 10
kick_scooter_speed = 5

# 도로 설정
road_image = pygame.Surface((width, height), pygame.SRCALPHA)  # 도로 이미지 설정
road_width = width // 3
road_change_speed = 1
current_road_width = road_width
center_line_color = (255, 255, 0)  # 노란색
center_line_width = 5
center_line_spacing = 20  # 중앙선 간격
center_line_length = 10  # 중앙선 길이
road_shape = "straight"  # 초기 도로 형태

# 장애물 설정
obstacle_width = 40
obstacle_height = 40
obstacle_speed = 5
obstacle_frequency = 50  # 장애물 등장 빈도
obstacles = []
obstacle_direction = "down"  # 장애물의 등장 방향

# 점수 및 타이머 설정
score = 25  # 초기 점수는 25점
time_limit = 3 * 60  # 초로 변환 (3분)
current_time = time_limit  # 초로 변환
font = pygame.font.Font(None, 36)

# 게임 오버 여부
game_over = False

# 게임 루프
while current_time > 0 and not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            print("게임 종료")
            pygame.quit()
            sys.exit()

    # 킥보드 이동
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and kick_scooter_x > (width - current_road_width) // 2:
        kick_scooter_x -= kick_scooter_speed
    if keys[pygame.K_RIGHT] and kick_scooter_x < (width + current_road_width) // 2 - kick_scooter_image.get_width():
            kick_scooter_x += kick_scooter_speed

    # 도로 변화 처리
    def draw_road():
        road_image.fill((0, 0, 0, 0))  # 투명 배경으로 초기화
        pygame.draw.rect(road_image, (169, 169, 169), [0, 0, (width - current_road_width) // 2, height])
        pygame.draw.rect(road_image, (169, 169, 169), [(width + current_road_width) // 2, 0, (width - current_road_width) // 2, height])
        
        # 중앙선 그리기
        if road_shape == "straight":
            pygame.draw.line(road_image, center_line_color, (width // 2, 0), (width // 2, height), center_line_width)
        elif road_shape == "diagonal_left_up":
            for i in range(0, height, center_line_spacing + center_line_length):
                pygame.draw.line(road_image, center_line_color, (width // 2, i), (width // 2 + center_line_length, i + center_line_length), center_line_width)
        elif road_shape == "diagonal_right_up":
            for i in range(0, height, center_line_spacing + center_line_length):
                pygame.draw.line(road_image, center_line_color, (width // 2, i), (width // 2 - center_line_length, i + center_line_length), center_line_width)
        elif road_shape == "right_turn":
            pygame.draw.arc(road_image, center_line_color, pygame.Rect((width - current_road_width) // 2, 0, current_road_width, height), 0, math.pi / 2, center_line_width)
        elif road_shape == "left_turn":
            pygame.draw.arc(road_image, center_line_color, pygame.Rect((width + current_road_width) // 2 - current_road_width, 0, current_road_width, height), -math.pi / 2, 0, center_line_width)
        elif road_shape == "circle":
            pygame.draw.circle(road_image, center_line_color, (width // 2, height // 2), current_road_width // 2, center_line_width)
    
    # 장애물 생성
    if random.randrange(0, obstacle_frequency) == 0:
        obstacle_x = random.randrange((width - current_road_width) // 2, (width + current_road_width) // 2 - obstacle_width)
        obstacle_y = -obstacle_height
        obstacle_choice = random.choice([
            obstacle_traffic_light_image,
            obstacle_banana_image,
            obstacle_car_image,
            obstacle_mother_and_child_image
        ])
        obstacles.append([obstacle_x, obstacle_y, obstacle_choice])

    # 장애물 이동
    for obstacle in obstacles:
        obstacle[1] += obstacle_speed

    # 충돌 검사
    for obstacle in obstacles:
        obstacle_rect = pygame.Rect(obstacle[0], obstacle[1], obstacle_width, obstacle_height)
        kick_scooter_rect = pygame.Rect(kick_scooter_x, kick_scooter_y, kick_scooter_image.get_width(), kick_scooter_image.get_height())

        if kick_scooter_rect.colliderect(obstacle_rect):
            score -= 5
            obstacles.remove(obstacle)

    # 시간 및 점수 갱신
    current_time -= 1

    # 게임 오버 조건
    if score < 0:
        game_over = True

    # 화면 지우기
    screen.blit(background_image, (0, 0))

    # 배경에 도로 그리기
    draw_road()

    # 킥보드 그리기
    screen.blit(kick_scooter_image, (kick_scooter_x, kick_scooter_y))

    # 장애물 그리기
    for obstacle in obstacles:
        screen.blit(obstacle[2], (obstacle[0], obstacle[1]))

    # 점수 표시
    text_score = font.render(f"Score: {score}", True, (255, 255, 255))
    screen.blit(text_score, (width - 150, 10))

    # 시간 표시
    text_time = font.render(f"Time: {current_time // 60:02d}:{current_time % 60:02d}", True, (255, 255, 255))
    screen.blit(text_time, (10, 10))

    # 게임 오버 시 처리
    if game_over:
        text_game_over = font.render("Game Over", True, (255, 0, 0))
        text_final_score = font.render(f"Final Score: {score}", True, (255, 255, 255))
        screen.blit(text_game_over, (width // 2 - 100, height // 2 - 30))
        screen.blit(text_final_score, (width // 2 - 120, height // 2 + 20))
        pygame.display.flip()
        pygame.time.delay(3000)  # 3초 대기
        pygame.quit()
        sys.exit()

    # 화면 업데이트
    pygame.display.flip()

    # 초당 프레임 수 설정
    pygame.time.Clock().tick(60)
